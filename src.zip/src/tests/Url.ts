export class Url {
    static Url: string = '';
}