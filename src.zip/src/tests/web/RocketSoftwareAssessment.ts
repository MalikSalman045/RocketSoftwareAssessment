import { expect } from 'chai';
import DriverProvider from '../../com/testlio/lib/driver/DriverProvider';
import { Browser } from 'webdriverio';
import ExecutionHelper from '../../com/testlio/lib/utils/ExecutionHelper';
import { WebdriverIoHomePage } from "../../com/testlio/pages/webdriverio/WebdriverIoHomePage";

let driver: Browser<'async'>;

let webdriverIoHomePage: WebdriverIoHomePage;
const group = '#Web2';
before(async () => {
    driver = await DriverProvider.createDriver();
});

it('WebdriverIO Home Page Test', async () => {
    webdriverIoHomePage = new WebdriverIoHomePage(driver);
    await driver.maximizeWindow();
    webdriverIoHomePage = await webdriverIoHomePage.open('https://webdriver.io/', webdriverIoHomePage);
    await ExecutionHelper.sleepInSeconds(5);
    await webdriverIoHomePage.copyGoogleLightHouseCodeSnippet();
    const noOfLines: number = await webdriverIoHomePage.getNoOfCodeSnippetLines();
    console.log('No of Code snippet lines: ' + noOfLines);
    expect(noOfLines).to.equal(16);
});

after(async () => {
    await driver.deleteSession();
});