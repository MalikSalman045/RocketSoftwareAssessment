import { step } from 'allure-decorators';
import AllureReportHelper from '../lib/utils/AllureReportHelper';
type BrowserSync = import('webdriverio/build/types').Browser<'async'>;
type ElementSync = import('webdriverio/build/types').Element<'async'>;


// tslint:disable-next-line:class-name
export abstract class page {
    private readonly driver: BrowserSync;
    protected constructor(driver) {
        this.driver = driver;
    }

    public getDriver(): BrowserSync {
        return this.driver;
    }

    public async openUrl(url: string) {
        await this.driver.url(url);
    }

    public async inputElement() {
        const inputElem = await this.driver.$('#search_form_input_homepage');
        await inputElem.setValue('WebdriverIO');
    }

    @step('Is element present by selector')
    public async isElementPresentBySelector(selector): Promise<boolean> {
        AllureReportHelper.createAllureParameters('selector', `${selector}`);
        try {
            return await this.driver.$(selector).isEnabled();
        } catch (e) {
            return false;
        }
    }

    /**
     * Check if element by selector is displayed
     * @param selector
     */
    @step('Is element displayed by selector')
    public async isElementDisplayedBySelector(selector): Promise<boolean> {
        AllureReportHelper.createAllureParameters('selector', `${selector}`);
        try {
            return await this.driver.$(selector).isDisplayed();
        } catch (e) {
            return false;
        }
    }

    @step('Set value to element by selector')
    public async setValueToElementBySelector(selector, input) {
        AllureReportHelper.createAllureParameters('selector,input', `${selector},${input}`);
        await this.driver.$(selector).setValue(input);
    }

    @step('Click on element by selector')
    async clickOnElementBySelector(selector) {
        AllureReportHelper.createAllureParameters('selector', `${selector}`);
        await this.driver.$(selector).click();
    }

    @step('Resolve element locator')
    async resolveElementLocator(element: ElementSync) {
        await AllureReportHelper.attachScreenShot(this.getDriver());
    }

    @step('Hover to element by selector')
    async hoverToElementBySelector(element: ElementSync) {
        AllureReportHelper.createAllureParameters('element.selector', `${element.selector}`);
        await element.moveTo();
    }
}