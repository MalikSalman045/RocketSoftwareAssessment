import { Browser } from 'webdriverio';
import AppObjsMap from '../../lib/appObjects/AppObjsMap';
import { step } from 'allure-decorators';
import { TestlioGlobalHeader } from './chunks/TestlioGlobalHeader';
import ExecutionHelper from '../../lib/utils/ExecutionHelper';
import { TestlioGlobalNetworkPage } from './TestlioGlobalNetworkPage';
import Webpage from '../../lib/pageFactory/Webpage';
import initPage from '../../lib/pageFactory/InitPage';
import ScreenShotUtility from '../../lib/utils/ScreenShotUtility';
import AllureReportHelper from '../../lib/utils/AllureReportHelper';

export class TestlioGlobalHomePage extends Webpage {
    constructor(driver: Browser<'async'>) {
        super(driver);
    }

    async isPageLoaded() {}

    get testlioTitleBar() { return AppObjsMap.appObjs.get('testlioTitleBar'); }

    get applyToFreelanceButton() { return AppObjsMap.appObjs.get('applyToFreelanceButton'); }

    get requestADemoButton() { return AppObjsMap.appObjs.get('requestADemoButton'); }

    testlioGlobalHeader: TestlioGlobalHeader = new TestlioGlobalHeader(this.getDriver());

    @step('Is Apply to freelance button present')
    async isApplyToFreelanceButtonPresent() {
        await AllureReportHelper.attachScreenShot(this.driver);
        return await this.isElementPresentBySelector(this.applyToFreelanceButton);
    }

    @step('Is Request a Demo button present')
    async isRequestADemoButtonPresent() {
        return await this.isElementPresentBySelector(this.requestADemoButton);
    }

    @step('Click Apply to freelance button')
    async clickApplyToFreelanceButton(): Promise<TestlioGlobalNetworkPage> {
        await this.scrollToWebElementAlignedToBottom(await this.driver.$(this.applyToFreelanceButton));
        await this.clickOnElementBySelector(this.applyToFreelanceButton);
        await ExecutionHelper.sleepInSeconds(2);
        return initPage.initPage(new TestlioGlobalNetworkPage(this.driver));
    }
    @step('Full page image validation')
    async checkFullPage(): Promise<number> {
        return await ScreenShotUtility.compareImages(this.driver);
    }
}