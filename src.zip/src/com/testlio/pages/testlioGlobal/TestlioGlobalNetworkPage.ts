import { Browser } from 'webdriverio';
import AppObjsMap from '../../lib/appObjects/AppObjsMap';
import { step } from 'allure-decorators';
import Webpage from '../../lib/pageFactory/Webpage';
import ExecutionHelper from '../../lib/utils/ExecutionHelper';

export class TestlioGlobalNetworkPage extends Webpage {
    constructor(driver: Browser<'async'>) {
        super(driver);
    }

    async isPageLoaded(): Promise<void> {
        await ExecutionHelper.sleepInSeconds(5);
        await this.driver.waitUntil(() => true);
    }

    get applyToFreelanceButtonOnNetworkPage() { return AppObjsMap.appObjs.get('applyToFreelanceButtonOnNetworkPage'); }

    @step('Is Apply to Freelance Button present')
    async isApplyToFreelanceButtonPresent() {
        return await this.isElementPresentBySelector(this.applyToFreelanceButtonOnNetworkPage);
    }

    @step('TESTING BIG')
    async returnGood(): Promise<string>{
        return "ALL IZZZZZZ GOOD";
    }
}