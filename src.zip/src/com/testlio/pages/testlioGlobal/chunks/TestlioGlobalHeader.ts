import { page } from '../../page';
import { Browser, Element } from 'webdriverio';
import AppObjsMap from '../../../lib/appObjects/AppObjsMap';
import ExecutionHelper from '../../../lib/utils/ExecutionHelper';
import { step } from 'allure-decorators';
import AllureReportHelper from '../../../lib/utils/AllureReportHelper';

export class TestlioGlobalHeader extends page {
    constructor(driver: Browser<'async'>) {
        super(driver);
    }

    get menuList() { return AppObjsMap.appObjs.get('menuList'); }

    get aboutLink() { return AppObjsMap.appObjs.get('aboutLink'); }

    @step('Hover Company menu item')
    async hoverToCompanyMenuItem(itemText: string) {
        AllureReportHelper.createAllureParameters('itemText', `${itemText}`);
        const elem: Element<'async'> = await this.getDriver().$(this.menuList).$(`.//a[text()='${itemText}']`);
        await this.hoverToElementBySelector(elem);
        await ExecutionHelper.sleepInSeconds(10);
    }

    @step('Is About link present')
    async isAboutLinkPresent() {
        return await this.isElementPresentBySelector(this.aboutLink);
    }
}