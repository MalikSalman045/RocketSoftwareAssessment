import { Browser, ElementArray } from 'webdriverio';
import AppObjsMap from '../../lib/appObjects/AppObjsMap';
import { step } from 'allure-decorators';

import Webpage from '../../lib/pageFactory/Webpage';
import AllureReportHelper from '../../lib/utils/AllureReportHelper';

export class WebdriverIoHomePage extends Webpage {
    constructor(driver: Browser<'async'>) {
        super(driver);
    }

    get webdriverIOLogo() { return AppObjsMap.appObjs.get('webdriverIOLogo'); }

    get googleLightHouseIntegrationHeader() { return AppObjsMap.appObjs.get('googleLightHouseIntegrationHeader'); }

    get googleLightHouseIntegrationCodeSection() { return AppObjsMap.appObjs.get('googleLightHouseIntegrationCodeSection'); }

    get googleLightHouseIntegrationCodeCopyButton() { return AppObjsMap.appObjs.get('googleLightHouseIntegrationCodeCopyButton'); }

    get googleLightHouseIntegrationCodeSnippetLines() { return AppObjsMap.appObjs.get('googleLightHouseIntegrationCodeSnippetLines'); }

    @step('Is WebdriverIO Logo Displayed ')
    async isWebdriverIOLogoDisplayed() {
        await AllureReportHelper.attachScreenShot(this.driver);
        return await this.isElementDisplayedBySelector(this.webdriverIOLogo);
    }

    @step('Copy Google Light House Code snippet')
    async copyGoogleLightHouseCodeSnippet(): Promise<string> {
        await AllureReportHelper.attachScreenShot(this.driver);
        let snippet = '';
        await this.jsScrollToWebElement(await this.driver.$(this.googleLightHouseIntegrationHeader));
        await this.hoverToElement(await this.driver.$(this.googleLightHouseIntegrationCodeSection));
        // await this.clickOnElementBySelector(this.googleLightHouseIntegrationCodeCopyButton);
        snippet = await this.getElementTextBySelector(this.googleLightHouseIntegrationCodeSection);
        console.log(snippet);
        return snippet;
    }

    @step('Get no of code snippet lines')
    async getNoOfCodeSnippetLines(): Promise<number> {
        let noOfSnippetLines: ElementArray;
        noOfSnippetLines = await this.driver.$$(this.googleLightHouseIntegrationCodeSnippetLines);
        return noOfSnippetLines.length;
    }
}