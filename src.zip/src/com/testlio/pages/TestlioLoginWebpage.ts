import { page } from './page';
import { Browser } from 'webdriverio';
import AppObjsMap from '../lib/appObjects/AppObjsMap';
import { step } from 'allure-decorators';
import AllureReportHelper from '../lib/utils/AllureReportHelper';

export class TestlioLoginWebpage extends page {
    constructor(driver: Browser<'async'>) {
        super(driver);
    }

    get emailInput(): string { return AppObjsMap.appObjs.get('emailInput'); }

    get passwordInput(): string { return AppObjsMap.appObjs.get('passwordInput'); }

    get loginButton(): string { return AppObjsMap.appObjs.get('loginButton'); }

    @step('Perform login ')
    async performLogin(userName: string, password: string): Promise<void> {
        AllureReportHelper.createAllureParameters('userName,password', `${userName}, ${password}`);

        await this.setValueToElementBySelector(this.emailInput, userName);
        await this.setValueToElementBySelector(this.passwordInput, password);
        await this.clickOnElementBySelector(this.loginButton);
    }
}