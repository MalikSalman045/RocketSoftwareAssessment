import AppObjsMap from "../../../lib/appObjects/AppObjsMap";
import { step } from "allure-decorators";
import { Browser } from "webdriverio";
import MobileScreen from '../../../lib/pageFactory/Mobilescreen';

export default class UserNotificationWidget extends MobileScreen {
    constructor(driver: Browser<'async'>) {
        super(driver);
    }

    get dontAllowButton(): string { return AppObjsMap.appObjs.get('dontAllowButton'); }

    @step('Click Dont Allow button, if present')
    async clickDontAllowButton() {
        if (await this.isElementPresentBySelector(this.dontAllowButton)) {
            await this.clickOnElementBySelector(this.dontAllowButton);
        }
    }
}
