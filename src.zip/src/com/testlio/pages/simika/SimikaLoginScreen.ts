import AppObjsMap from '../../lib/appObjects/AppObjsMap';
import { step } from 'allure-decorators';
import { Browser } from 'webdriverio';
import UserNotificationWidget from "./widgets/UserNotificationWidget";
import { SimikaHomeScreen } from './SimikaHomeScreen';
import AllureReportHelper from '../../lib/utils/AllureReportHelper';
import initPage from '../../lib/pageFactory/InitPage';
import MobileScreen from '../../lib/pageFactory/Mobilescreen';

export class SimikaLoginScreen extends MobileScreen {
    constructor(driver: Browser<'async'>) {
        super(driver);
    }
    get testlioLabel(): string { return AppObjsMap.appObjs.get('testlioLabel'); }

    get emailField(): string { return AppObjsMap.appObjs.get('emailField'); }

    get passwordField(): string { return AppObjsMap.appObjs.get('passwordField'); }

    get loginButton(): string { return AppObjsMap.appObjs.get('loginButton'); }

    userNotificationWidget: UserNotificationWidget = new UserNotificationWidget(this.getDriver());

    @step('Is testlio label present')
    async isTestlioLabelPresent(): Promise<boolean> {
        return await this.isElementPresentBySelector(this.testlioLabel);
    }

    @step('Is login button present')
    async isLoginButtonPresent(): Promise<boolean> {
        await AllureReportHelper.attachScreenShot(this.getDriver());
        return await this.isElementPresentBySelector(this.loginButton);
    }

    @step('Perform login')
    async performLogin(userName: string, password: string): Promise<SimikaHomeScreen> {
        await this.setValueToElementBySelector(this.emailField, userName);
        await this.setValueToElementBySelector(this.passwordField, password);
        await this.clickOnElementBySelector(this.loginButton);
        return initPage.initPage(new SimikaHomeScreen(this.getDriver()));
    }
}