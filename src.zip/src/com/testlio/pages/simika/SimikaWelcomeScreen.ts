import { Browser } from 'webdriverio';
import AppObjsMap from '../../lib/appObjects/AppObjsMap';
import { step } from 'allure-decorators';
import MobileScreen from '../../lib/pageFactory/Mobilescreen';

export class SimikaWelcomeScreen extends MobileScreen {
    constructor(driver: Browser<'async'>) {
        super(driver);
    }

    get welcomeBackText(): string { return AppObjsMap.appObjs.get('welcomeBackText'); }

    @step("Is Welcome Back text present")
    async isWelcomeBackTextPresent(): Promise<boolean> {
        return this.isElementPresentBySelector(this.welcomeBackText);
    }
}