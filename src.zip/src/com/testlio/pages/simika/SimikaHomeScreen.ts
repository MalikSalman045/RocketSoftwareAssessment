import { Browser } from 'webdriverio';
import AppObjsMap from '../../lib/appObjects/AppObjsMap';
import { step } from 'allure-decorators';
import AutomationProperties from '../../lib/properties/AutomationProperties';
import { SimikaWelcomeScreen } from './SimikaWelcomeScreen';
import ExecutionHelper from '../../lib/utils/ExecutionHelper';
// import ScreenShotUtility from '../../lib/utils/ScreenShotUtility';
import MobileScreen from '../../lib/pageFactory/Mobilescreen';

export class SimikaHomeScreen extends MobileScreen {
    constructor(driver: Browser<'async'>) {
        super(driver);
    }

    get parentImage(): string { return AppObjsMap.appObjs.get('parentImage'); }

    get signInText(): string { return AppObjsMap.appObjs.get('signInText'); }

    get teacherImage(): string { return AppObjsMap.appObjs.get('teacherImage'); }

    get schoolImage(): string { return AppObjsMap.appObjs.get('schoolImage'); }

    get parentButton(): string { return AppObjsMap.appObjs.get('parentButton'); }

    @step('Is Sign In Text Present')
    async isSignInTextPresent(): Promise<boolean> {
        return await this.isElementPresentBySelector(this.signInText);
    }

    @step('Is Parent Image present')
    async isParentImagePresent(): Promise<boolean> {
        return await this.isElementPresentBySelector(this.parentImage);
    }

    @step('Is Teacher Image present')
    async isTeacherImagePresent(): Promise<boolean> {
        return await this.isElementPresentBySelector(this.teacherImage);
    }

    @step('Is School Image present')
    async isSchoolImagePresent(): Promise<boolean> {
        return await this.isElementPresentBySelector(this.schoolImage);
    }

    @step('Click Parent Image')
    async clickParentImage(): Promise<SimikaWelcomeScreen> {
        if (AutomationProperties.isIOSExecution()) {
            await this.clickOnElementBySelector(this.parentButton);
        } else {
            await this.clickOnElementBySelector(this.parentImage);
        }

        await ExecutionHelper.sleepInSeconds(5);

        return new SimikaWelcomeScreen(this.getDriver());
    }

}