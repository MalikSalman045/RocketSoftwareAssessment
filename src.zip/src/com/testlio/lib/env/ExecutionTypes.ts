enum ExecutionTypes {
    WEB = 'web',
    MOBILE_NATIVE = 'Mobile-Native',
    MOBILE_WEB = 'Mobile-Web'
}

export default ExecutionTypes;
