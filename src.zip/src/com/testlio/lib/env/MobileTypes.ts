enum MobileTypes {
    ANDROID = 'Android',
    IOS = 'iOS',
}

export default MobileTypes;
