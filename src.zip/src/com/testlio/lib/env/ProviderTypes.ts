enum ProvidersTypes {
    LOCAL = 'local',
    TESTLIO = 'testlio',
}

export default ProvidersTypes;